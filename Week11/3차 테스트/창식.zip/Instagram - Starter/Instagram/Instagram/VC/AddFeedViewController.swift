//
//  AddFeedViewController.swift
//  Instagram
//
//  Created by Wi on 30/04/2019.
//  Copyright © 2019 Wi. All rights reserved.
//

import UIKit

// 카메라로 사진을 찍거나 앨범에서 사진을 선택할 시에 오게될 컨트롤러입니다.
// 오른쪽 상단에 공유버튼을 올리고 공유를 누르면 Feed를 추가합니다.
// 기본 값이 UITableViewController 입니다. 기본 뷰컨트롤러로 구현하고 싶으시면 타입을 UIViewController로 바꿔주세요.

class AddFeedViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .yellow
        
        configure()
    }
    
    private func configure() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "공유", style: .done, target: self, action: #selector(shareBtnDidTapped(_:)))
    }
    
    @objc private func shareBtnDidTapped(_ sender: Any) {
        
    }

}
