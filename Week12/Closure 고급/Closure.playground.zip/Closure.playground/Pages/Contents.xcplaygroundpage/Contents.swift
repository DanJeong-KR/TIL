/*:
 # Closure
 
 - Closure
 - CaptureList
 - NoEscaping
 - Escaping
 - MemoryLeak
 - AutoClosure
 
 by Giftbot
*/
//: [Next](@next)
